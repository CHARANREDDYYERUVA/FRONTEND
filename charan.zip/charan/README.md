
# Charan - EmptyCup Assignment

## Instructions

### Local Deployment (Docker)
1. Install Docker and Docker Compose.
2. Run: `docker-compose up --build`
3. Visit: `http://localhost:5000`

### Features
- Responsive mobile-first web page styled per Figma spec.
- Dynamic shortlist toggle.
- Backend JSON data served with Flask.

### File Structure
- `frontend/`: HTML, CSS, JS
- `backend/`: Flask app
- `data/`: Static JSON file
