
from flask import Flask, jsonify, send_from_directory

app = Flask(__name__, static_folder='../frontend', static_url_path='')

@app.route('/')
def index():
    return app.send_static_file('index.html')

@app.route('/data/<path:filename>')
def data(filename):
    return send_from_directory('../data', filename)

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0')
